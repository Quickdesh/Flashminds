import random
import time
import os#A new module we learnt during our time at the hackathon

score=0#setting score

list1=['thrill','yak','thumb','vegetable','advise','silly','compare','noisy','messy','ice','hope','hideous','afford','cross','relieved','skirt','schedule','sheep','lamp','crush','well','peaceful','swim','market','yummy','lie','used','frogs','pretend','stop','hello','bottle','wallet','laptop','light','bulb','handkerchief','ball','sharpener','coin','watch','clock','button','keyboard','mouse','sticker','ruler','biography','wires','stapler','hackathon','python','nuance'] #the list that contains the dictionary for the test

usedlist=[]#the list where the words seen will be sent

print('This test is to analyse your memory skills')
print('We will display 20 words, which you have to memorize to the best of your ability. Then we will display a few words and you have to tell us whether you have seen that word or not') #stating the question
time.sleep(5)
print('Are you ready?')
time.sleep(2)
print('Here we go!')

i=1
while i<=20: #loop for displaying 20 words and dissapearing after
    word=random.choice(list1)
    if word not in usedlist:
        usedlist.append(word) #puts the word in the list which has the displayed words
        print(word)
        time.sleep(0.75)
        os.system('CLS') #clears the word
        i+=1

time.sleep(2)
print('Are the words in your memory?')
time.sleep(2)
print('lets find out!')
time.sleep(2)
print('We will show you 15 words. Press "y" if you remember seeing it or press "n" if it was not shown') #the second question

for i in range(15):
    word2=random.choice(list1) #chooses random word to ask the user
    print('The word:',word2)
    urans=input('was this word shown?').lower() #ask the user for the answer
    if word2 in usedlist:
        ans='y'
    else:
        ans='n'
    if urans==ans: #checks if answer is correct
        score+=1

print('Your score is',score,'out of 15') #prnts your score and percentage
perc=(score/15)*100
print('Your memory skills are about ',perc,'%',sep='')
 
