import time
print('ROCK PAPER SCISSORS GAME\n') #description of the game
print("RULES:\nscissor beats paper\npaper beats rock\nrock beats scissors\n")
time.sleep(3)
print('When the shell prompts you for your play, type in your choice\n')
time.sleep(2)
print("You get to play until you lose once")
time.sleep(3)
import random
score=0
compscore=0
comp=['ROCK','SCISSORS','PAPER'] #list for the computer to choose from
while compscore==0:
    compplay=random.choice(comp) #computer chooses its play
    play=(input('ROCK PAPER SCISSORS SHOOT..')).upper() #you enter your play
    if compplay==play:
        print('you both tied, go again')
    elif play=='ROCK' or play=='SCISSORS' or play=='PAPER':
        print('the computer chose',compplay) #primary working of the program in 3 user input scenarios
        if play=='ROCK':
            if compplay=='PAPER':
                print('you lose this round')
                compscore+=1
            elif compplay=='SCISSORS':
                print('you win this round')
                score+=1
        elif play=='SCISSORS':
            if compplay=='ROCK':
                print('you lose this round')
                compscore+=1
            elif compplay=='PAPER':
                print('you win this round')
                score+=1
        elif play=='PAPER':
            if compplay=='SCISSORS':
                print('you lose this round')
                compscore+=1
            elif compplay=='ROCK':
                print('you win this round')
                score+=1
    else:
        print('must be a spelling error, try again') #if user enters wrong choice
print('----------------------------------------------------------------------------')
print('GAME OVER')
print('your score is:',score) #displays the user's score