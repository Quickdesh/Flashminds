import time,random #Modules required for program
print('This is a reaction time test')
print("#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#")
print("When the computer says GO! hit the enter key")#Just an aesthetic description
print("#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#")
print("We're going to test you five times")
print("Then we'll give you your average time and result")
count=5
sum1=0

while count>0: #loop for playing 5 times
    time.sleep(1)
    print("Be prepared!")
    time.sleep(1)
    print("Any time now here we go")
    time.sleep(random.randint(2,5))
    firsttime = time.time()#Starts the timer
    a=input("PRESS ENTER!!!!!!!!")
    secondtime = time.time()#This ends the timer
    timetaken = secondtime-firsttime#Calculates time
    timetaken2 = timetaken*1000
    print("Your time taken is ", timetaken2,"ms") #prints the time you took
    sum1 += timetaken
    count=count-1

averagetime=sum1/5*1000 #calculates average time taken
print('The average time taken for this test is 284 ms')
time.sleep(2)
print("Your average time is ",averagetime,"ms") #prints your result according to the specifications

if averagetime<=100:
    print('You are as quick as a FLASH!!')
elif averagetime>100 and averagetime<=200:
    print('You are quicker than most!')
elif averagetime>200 and averagetime<=300:
    print('You take as much time as most people!')
elif averagetime>300 and averagetime<=400:
    print('You are a bit slower than most others')
else:
    print('You are too slow! Try harder next time!')
