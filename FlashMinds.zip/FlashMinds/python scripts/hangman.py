import random

name = input("What is your name? ")
 
print("Good Luck",name,'!')

print("Rules as simple as they are 10 chances to guess the correct alphabets each time, GOAL: to complete the word")
      
 
words = ['rainbow', 'computer', 'science', 'programming', #dictionary of words from which words will be provided
         'python', 'mathematics', 'player', 'condition', 
         'reverse', 'water', 'board', 'piano','corona', 'virus','hack','memory'
         'chess','color','smart','dynamic','travel','nostalgic','versatile','abstract','nutrition'
         'radiant','luminous','abundant','classic',"hackathon","python"] 

i=0
while i<3: 
    word = random.choice(words) #chooses a random word from the list
 
    print("Guess the characters")
 
    guesses = ''
 
    turns = 10 #number of turns

    while turns > 0:

        failed = 0

        for calpha in word: 

            if calpha in guesses: 
                print(calpha,end=' ') #If the letter is in the word it prints the letter

            else: 
                print("_",end=" ")#otherwise it remains the same

                failed += 1

 
        if failed == 0: #in case you get all the letters

            print("\nYou Win") 

            print("\nThe word is:",word) 
            break

        guess = input("\nguess a character:") #asks for the character you think is in the word

        guesses += guess 

        if guess not in word: #in case the letter you guessed is not in the word

            turns -= 1

            print("Wrong")

            print("You have", + turns, 'more guesses')

            if turns == 0: #if you run out of turns you lose
                print("You Lose")
                print('The word was',word)
    i+=1
