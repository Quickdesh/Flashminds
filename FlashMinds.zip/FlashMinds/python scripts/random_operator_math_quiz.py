import random
import time

timesum=0

operators = ["+","-","*","/"] #list of operators to choose from

print("We'll give you 2 random numbers and a randomly generated operator\n") #defining the question
print('You will be timed so make sure to answer as quickly as possible')
print("if You by mistakenly input something else except an integer just rerun the program")

time.sleep(3)
print('Are you ready?')
time.sleep(3)  
score=0
i=0
while i<8:
    num1= random.randint(1,50) #choosing the numbers
    num2= random.randint(1,50)

    o=random.randint(0,3) #choosing random operator
    ans=0
    a = operators[o]
    if a=="+":
        ans=num1+num2
    elif a=="-":
        ans=num1-num2
    elif a=="*":
        ans=num1*num2
        if ans>200: #we don't want the asnwer to be too big so it should be less than 200
                continue
    elif a=="/":
        ans=num1/num2
        if ans.is_integer(): #we want the quotient to be a whole number
            ans=ans
        else:
            continue
    print('What is',num1,a,num2,'?') #the question is displayed
    t1=time.time() #starts the timer
    guess=int(input("Enter your answer: ")) #ask user for the answer
    t2=time.time() #ends the timer
    timet=t2-t1 #calculates time taken
        
    if (guess==ans):
        score += 1
        print ("Correct!")
        print('You took',timet,'seconds to answer this question')
    else:
        print("Incorrect!")
        print('You took',timet,'seconds to answer this question')
        print("The correct answer was: ",ans)
    
    timesum+=timet #adds time taken to the sum
    i+=1

print("Your final score is:",score,'out of 8!') #computes your score out of 5
avgtime=timesum/8 #computes average time
print('Average time taken for each question:',avgtime) #displays average time

print('The average time taken for this test is 6 seconds')
time.sleep(2) #to calculate the range in which the user falls based on the time they take
print("Your average time is ",avgtime,"s")
if avgtime<=2:
    print('You are as quick as a cat!!')
elif avgtime>2 and avgtime<=4:
    print('You are quicker than most!')
elif avgtime>4 and avgtime<=6:
    print('You take as much time as most people!')
elif avgtime>6 and avgtime<=8:
    print('You are a bit slower than most others')
else:
    print('You are too slow! Try harder next time!')
