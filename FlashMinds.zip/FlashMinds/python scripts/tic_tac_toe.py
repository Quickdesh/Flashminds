import random

def titato():

     tt=["_","_","_","_","_","_"," "," "," "] #list for tic-tac-toe table
     ts=["1","2","3","4","5","6","7","8","9"] #list for number reference table

     def tttb(): #code to create the table
          l1=tt[0]+"|"+tt[1]+"|"+tt[2]+"\t"
          l2=tt[3]+"|"+tt[4]+"|"+tt[5]+"\t"
          l3=tt[6]+"|"+tt[7]+"|"+tt[8]+"\t"
            
          l4=ts[0]+"|"+ts[1]+"|"+ts[2]
          l5=ts[3]+"|"+ts[4]+"|"+ts[5]
          l6=ts[6]+"|"+ts[7]+"|"+ts[8]
            
          print(l1+l4)
          print(l2+l5)
          print(l3+l6)
            


     tttb()
      
     #main code

     for i in range(9):
          k=True
          while k:
               w=" " #variable to define the winner
               if i%2==0: #x's turn as long as i is even
                    print("Where would you like to place? (X) ")
                    m=int(input())
                    if tt[m-1]!="X" and tt[m-1]!="O": #m-1 because difference in index and number table
                         tt[m-1],ts[m-1]="X","X"
                         k=False
                        
                  
               else:
                    m=random.randint(1,9)
                    while tt[m-1]=="X" or tt[m-1]=="O": #program randomly places for O
                         m=random.randint(1,9)
                    tt[m-1],ts[m-1]="O","O"
                    tttb()
                    k=False
                                    
                              
                    if tt[m-1]!="X" and tt[m-1]!="O":
                         tt[m-1],ts[m-1]="O","O"
                         k=False
               if k: #checks for winner
                    print("Enter another location")
               if   tt[0]==tt[1] and tt[1]==tt[2]:
                        w=tt[0]
               elif tt[3]==tt[4] and tt[4]==tt[5]:
                        w=tt[3]
               elif tt[6]==tt[7] and tt[7]==tt[8]:
                        w=tt[6]
               elif tt[0]==tt[3] and tt[3]==tt[6]:
                        w=tt[0]
               elif tt[1]==tt[4] and tt[4]==tt[7]:
                        w=tt[1]
               elif tt[2]==tt[5] and tt[5]==tt[8]:
                        w=tt[2]
               elif tt[0]==tt[4] and tt[4]==tt[8]:
                        w=tt[0]
               elif tt[2]==tt[4] and tt[4]==tt[6]:
                        w=tt[2]
               #breaks out only if there is a winner
               if w!=" " and w!="_":
                    break
          #double break
          if w!=" " and w!="_":
                    print("The winner is",w)
                    break
     else:
          print("Tie")
            

titato()
