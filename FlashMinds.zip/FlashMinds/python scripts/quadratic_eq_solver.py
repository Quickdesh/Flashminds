import random
import time

e=True 
while e: #to select a quadratic equation that can be solved by the user

     a=0
     while a==0:
          a=random.randrange(-10,10)

     b=random.randrange(-10,10)
     c=random.randrange(-10,10)

     a2=a*2
     d=((b**2)-4*a*c)
     ans1=(-b+(d**0.5))/a2 #finding the roots of the equation
     ans2=(-b-(d**0.5))/a2

     if d<0:
          continue

     if ans1.is_integer() and ans2.is_integer():
          e=False

#adding both the answers in a list for later reference
finalans=[]
finalans.append(ans1)
finalans.append(ans2)

#to print the equation in a correct manner in the case of clashes of negative and positive symbols

if a==1:
     aa=""
elif a==-1:
     aa="- "
elif a<0:
     aa=str(abs(a))
     aa="-"+aa

else:
     aa=str(a)

if b==1:
     bb="+ "
elif b==-1:
     bb="- "
elif b<0:
     bb=str(abs(b))
     bb="- "+bb
else:
     bb=str(b)
     bb="+ "+bb

if c<0:
     cc=str(abs(c))
     cc="- "+cc
else:
     cc=str(c)
     cc="+ "+cc

sup=("⁰","¹","²","³","⁴","⁵","⁶","⁷","⁸","⁹","¹/²")

print('Solve this quadratic equation:')
print("Your question:\n")

print(aa,"x",sup[2]," ",bb,"x ",cc," = 0\n",sep="") #print the question

urans1=int(input("Enter your first answer: ")) #ask the user for their answers
urans2=int(input("Enter your second answer: "))

if urans1 in finalans and urans2 in finalans: #check whether the answers are in the list and how many of them they got correct
    print('Congratulations, both your answers are correct')
elif urans1 in finalans or urans2 in finalans:
     print('You got 1 answer correct, the answers are',ans1,'and',ans2)
else:
    print('Wrong answers!! The answers are',ans1,'and',ans2)

choice=int(input('enter "1" if you want to see how you get the answer step by step or press "2" to exit')) #to ask if the ser wants an explanation as to how they arrive at the answer
if choice==1:
     print('Your question was:\n',aa,"x",sup[2]," ",bb,"x ",cc," = 0\n",sep="") #shows a step by step method of how to solve the question
     print('To solve this question, we will use the quadratic formula')
     time.sleep(3)
     print('QUADRATIC FORMULA:')
     print("\033[4m-b±(b²-4ac)\033[0m",sup[10])
     print('    2a   ')
     time.sleep(5)
     print('Here "(b²-4ac)" is known as the discriminant. Lets evaluate that first')
     print('substitute the values of a,b and c in the expression. Here, a=',a,'b=',b,'c=',c)
     print('Therefore, the discriminant will be equal to: ',b,'²','-','( 4 x',a,'x',c,')',sep=' ')
     time.sleep(2)
     print('Which is equal to:',d)
     time.sleep(7)
     inter1=-b+(d**0.5)
     inter2=-b-(d**0.5)
     print('now complete evaluating the numerator: -b±(b²-4ac)',sup[10],sep='')  
     time.sleep(2) 
     print('which is equal to:',inter1,'and',inter2)
     time.sleep(5)
     print('now you divide the numerator by 2 x',a)
     time.sleep(2)
     print('then you get your answers:',inter1/(a2),'and',inter2/(a2))
     print("And that's how you solve a quadratic equation using the quadratic formula!")
else:
     exit