#!/usr/bin/python3
from tkinter import *
from random import randint, shuffle
from time import sleep
import os
import sys

#

G=[]
G.append([0, 0, 0, 0, 0, 0, 0, 0, 0])
G.append([0, 0, 0, 0, 0, 0, 0, 0, 0])
G.append([0, 0, 0, 0, 0, 0, 0, 0, 0])
G.append([0, 0, 0, 0, 0, 0, 0, 0, 0])
G.append([0, 0, 0, 0, 0, 0, 0, 0, 0])
G.append([0, 0, 0, 0, 0, 0, 0, 0, 0])
G.append([0, 0, 0, 0, 0, 0, 0, 0, 0])
G.append([0, 0, 0, 0, 0, 0, 0, 0, 0])
G.append([0, 0, 0, 0, 0, 0, 0, 0, 0])



#Check if grid is full

def checkGrid(G):
  for row in range(0,9):
      for col in range(0,9):
        if G[row][col]==0:
          return False


  return True 

counter=0
c=0
#A backtracking function to check all possible combinations until a solution is found (used later)
def solveGrid(G):
  global counter

  #Find next empty cell
  
  for i in range(0,81):
    row=i//9
    col=i%9
    if G[row][col]==0:
      for value in range (1,10):
           
        #Check that this value has not already be used on this row
           
        if not(value in G[row]):
             
          #Check that this value has not already be used on this column
             
          if not value in (G[0][col],G[1][col],G[2][col],G[3][col],G[4][col],G[5][col],G[6][col],G[7][col],G[8][col]):

            #Which of the 9 squares is the program working on
               
            square=[]
            if row<3:
              if col<3:
                square=[G[i][0:3] for i in range(0,3)]
              elif col<6:
                square=[G[i][3:6] for i in range(0,3)]
              else:  
                square=[G[i][6:9] for i in range(0,3)]
            elif row<6:
              if col<3:
                square=[G[i][0:3] for i in range(3,6)]
              elif col<6:
                square=[G[i][3:6] for i in range(3,6)]
              else:  
                square=[G[i][6:9] for i in range(3,6)]
            else:
              if col<3:
                square=[G[i][0:3] for i in range(6,9)]
              elif col<6:
                square=[G[i][3:6] for i in range(6,9)]
              else:  
                square=[G[i][6:9] for i in range(6,9)]
                
            #Check that this value has not already be used on this 3x3 square
                
            if not value in (square[0] + square[1] + square[2]):
              G[row][col]=value
              if checkGrid(G):
                counter+=1
                break
              else:
                if solveGrid(G):
                  return True
      
      break   
  G[row][col]=0


numberList=[1,2,3,4,5,6,7,8,9]
#shuffle(numberList)

#A backtracking function to check all possible combinations until a solution is found

def fillGrid(G):   
  global counter
  
  #Find next empty cell
  
  for i in range(0,81):
    row=i//9
    col=i%9
    if G[row][col]==0:
      shuffle(numberList)      
      for value in numberList:
           
        #Check that this value has not already be used on this row
           
        if not(value in G[row]):

          #Check that this value has not already be used on this column
             
          if not value in (G[0][col],G[1][col],G[2][col],G[3][col],G[4][col],G[5][col],G[6][col],G[7][col],G[8][col]):

            #Which of the 9 squares is the program working on
               
            square=[]
            if row<3:
              if col<3:
                square=[G[i][0:3] for i in range(0,3)]
              elif col<6:
                square=[G[i][3:6] for i in range(0,3)]
              else:  
                square=[G[i][6:9] for i in range(0,3)]
            elif row<6:
              if col<3:
                square=[G[i][0:3] for i in range(3,6)]
              elif col<6:
                square=[G[i][3:6] for i in range(3,6)]
              else:  
                square=[G[i][6:9] for i in range(3,6)]
            else:
              if col<3:
                square=[G[i][0:3] for i in range(6,9)]
              elif col<6:
                square=[G[i][3:6] for i in range(6,9)]
              else:  
                square=[G[i][6:9] for i in range(6,9)]
                
            #Check if the value has already been used in this 3x3 square
                
            if not value in (square[0] + square[1] + square[2]):
              G[row][col]=value
              if checkGrid(G):
                return True
              else:
                if fillGrid(G):
                  return True
      break
  G[row][col]=0             
   
fillGrid(G)



#Start Removing Numbers one by one

attempts = 5 
counter=1
while attempts>0:
     
  #Selects a random cell that is not already empty
     
  row = randint(0,8)
  col = randint(0,8)
  while G[row][col]==0:
    row = randint(0,8)
    col = randint(0,8)
    
  #backup its cell value in case we need to put it back
    
  backup = G[row][col]
  G[row][col]=0
  
  cG = []
  for r in range(0,9):
     cG.append([])
     for c in range(0,9):
        cG[r].append(G[r][c])
        
   #Count the number of solutions that this grid has

  counter=0      
  solveGrid(cG)
  
  #If the number of solution is different from 1 then we need to undo the change
  
  if counter!=1:
    G[row][col]=backup
    
    #Keep trying to remove more numbers
    
    attempts -= 1

tG = []
for r in range(0,9):
     tG.append([])
     for c in range(0,9):
          if G[r][c]==0:
               tG[r].append(" ")
          else:
               tG[r].append(G[r][c])
               
#Restarts Program
               
def new():
     os.execv(sys.executable, ['python', __file__])
 
wid =Tk()              

# Open window having dimension 540x520

wid.geometry('540x520')

# Defines the frames for the buttons and text

start = Frame(wid)
start.pack()


sudtf = Frame(wid)
sudtf.pack()


mid = Frame(wid)
mid.pack()


numf = Frame(wid)
numf.pack()

end = Frame(wid)
end.pack()

last =Frame(wid)
last.pack()

#Vertical lines

vl="\u2502"

v01 = Label(sudtf,text=vl)
v02 = Label(sudtf,text=vl)
v03 = Label(sudtf,text=vl)
v04 = Label(sudtf,text=vl)
v05 = Label(sudtf,text=vl)
v06 = Label(sudtf,text=vl)
v07 = Label(sudtf,text=vl)
v08 = Label(sudtf,text=vl)
v09 = Label(sudtf,text=vl)
v10 = Label(sudtf,text=vl)
v11 = Label(sudtf,text=vl)
v12 = Label(sudtf,text=vl)
v13 = Label(sudtf,text=vl)
v14 = Label(sudtf,text=vl)
v15 = Label(sudtf,text=vl)
v16 = Label(sudtf,text=vl)
v17 = Label(sudtf,text=vl)
v18 = Label(sudtf,text=vl)

#Horizontal lines

hl="\u2501"

h01 = Label(sudtf,text=hl)
h02 = Label(sudtf,text=hl)
h03 = Label(sudtf,text=hl)
h04 = Label(sudtf,text=hl)
h05 = Label(sudtf,text=hl)
h06 = Label(sudtf,text=hl)
h07 = Label(sudtf,text=hl)
h08 = Label(sudtf,text=hl)
h09 = Label(sudtf,text=hl)
h10 = Label(sudtf,text=hl)
h11 = Label(sudtf,text=hl)
h12 = Label(sudtf,text=hl)
h13 = Label(sudtf,text=hl)
h14 = Label(sudtf,text=hl)
h15 = Label(sudtf,text=hl)
h16 = Label(sudtf,text=hl)
h17 = Label(sudtf,text=hl)
h18 = Label(sudtf,text=hl)

#Cross lines

cl="\u254B"

c01 = Label(sudtf,text=cl)
c02 = Label(sudtf,text=cl)
c03 = Label(sudtf,text=cl)
c04 = Label(sudtf,text=cl)

#Defines the commands for all the buttons 

a=" "
def s1():
     global a
     a=1
     bn["text"]=a
def s2():
     global a
     a=2
     bn["text"]=a
def s3():
     global a
     a=3
     bn["text"]=a
def s4():
     global a
     a=4
     bn["text"]=a
def s5():
     global a
     a=5
     bn["text"]=a
def s6():
     global a
     a=6
     bn["text"]=a
def s7():
     global a
     a=7
     bn["text"]=a
def s8():
     global a
     a=8
     bn["text"]=a
def s9():
     global a
     a=9
     bn["text"]=a
     
#assigns the values to the grid based on user input
     
def n11():
     if tG[0][0]==" ":
          n11["text"]=a
def n12():
     if tG[0][1]==" ":
          n12["text"]=a
def n13():
     if tG[0][2]==" ":
          n13["text"]=a
def n14():
     if tG[0][3]==" ":
          n14["text"]=a
def n15():
     if tG[0][4]==" ":
          n15["text"]=a
def n16():
     if tG[0][5]==" ":
          n16["text"]=a
def n17():
     if tG[0][6]==" ":
          n17["text"]=a
def n18():
     if tG[0][7]==" ":
          n18["text"]=a
def n19():
     if tG[0][8]==" ":
          n19["text"]=a


def n21():
     if tG[1][0]==" ":
          n21["text"]=a
def n22():
     if tG[1][1]==" ":
          n22["text"]=a
def n23():
     if tG[1][2]==" ":
          n23["text"]=a
def n24():
     if tG[1][3]==" ":
          n24["text"]=a
def n25():
     if tG[1][4]==" ":
          n25["text"]=a
def n26():
     if tG[1][5]==" ":
          n26["text"]=a
def n27():
     if tG[1][6]==" ":
          n27["text"]=a
def n28():
     if tG[1][7]==" ":
          n28["text"]=a
def n29():
     if tG[1][8]==" ":
          n29["text"]=a

     
def n31():
     if tG[2][0]==" ":
          n31["text"]=a
def n32():
     if tG[2][1]==" ":
          n32["text"]=a
def n33():
     if tG[2][2]==" ":
          n33["text"]=a
def n34():
     if tG[2][3]==" ":
          n34["text"]=a
def n35():
     if tG[2][4]==" ":
          n35["text"]=a
def n36():
     if tG[2][5]==" ":
          n36["text"]=a
def n37():
     if tG[2][6]==" ":
          n37["text"]=a
def n38():
     if tG[2][7]==" ":
          n38["text"]=a
def n39():
     if tG[2][8]==" ":
          n39["text"]=a

     
def n41():
     if tG[3][0]==" ":
          n41["text"]=a
def n42():
     if tG[3][1]==" ":
          n42["text"]=a
def n43():
     if tG[3][2]==" ":
          n43["text"]=a
def n44():
     if tG[3][3]==" ":
          n44["text"]=a
def n45():
     if tG[3][4]==" ":
          n45["text"]=a
def n46():
     if tG[3][5]==" ":
          n46["text"]=a
def n47():
     if tG[3][6]==" ":
          n47["text"]=a
def n48():
     if tG[3][7]==" ":
          n48["text"]=a
def n49():
     if tG[3][8]==" ":
          n49["text"]=a


def n51():
     if tG[4][0]==" ":
          n51["text"]=a
def n52():
     if tG[4][1]==" ":
          n52["text"]=a
def n53():
     if tG[4][2]==" ":
          n53["text"]=a
def n54():
     if tG[4][3]==" ":
          n54["text"]=a
def n55():
     if tG[4][4]==" ":
          n55["text"]=a
def n56():
     if tG[4][5]==" ":
          n56["text"]=a
def n57():
     if tG[4][6]==" ":
          n57["text"]=a
def n58():
     if tG[4][7]==" ":
          n58["text"]=a
def n59():
     if tG[4][8]==" ":
          n59["text"]=a


def n61():
     if tG[5][0]==" ":
          n61["text"]=a
def n62():
     if tG[5][1]==" ":
          n62["text"]=a
def n63():
     if tG[5][2]==" ":
          n63["text"]=a
def n64():
     if tG[5][3]==" ":
          n64["text"]=a
def n65():
     if tG[5][4]==" ":
          n65["text"]=a
def n66():
     if tG[5][5]==" ":
          n66["text"]=a
def n67():
     if tG[5][6]==" ":
          n67["text"]=a
def n68():
     if tG[5][7]==" ":
          n68["text"]=a
def n69():
     if tG[5][8]==" ":
          n69["text"]=a

          
def n71():
     if tG[6][0]==" ":
          n71["text"]=a
def n72():
     if tG[6][1]==" ":
          n72["text"]=a
def n73():
     if tG[6][2]==" ":
          n73["text"]=a
def n74():
     if tG[6][3]==" ":
          n74["text"]=a
def n75():
     if tG[6][4]==" ":
          n75["text"]=a
def n76():
     if tG[6][5]==" ":
          n76["text"]=a
def n77():
     if tG[6][6]==" ":
          n77["text"]=a
def n78():
     if tG[6][7]==" ":
          n78["text"]=a
def n79():
     if tG[6][8]==" ":
          n79["text"]=a


def n81():
     if tG[7][0]==" ":
          n81["text"]=a
def n82():
     if tG[7][1]==" ":
          n82["text"]=a
def n83():
     if tG[7][2]==" ":
          n83["text"]=a
def n84():
     if tG[7][3]==" ":
          n84["text"]=a
def n85():
     if tG[7][4]==" ":
          n85["text"]=a
def n86():
     if tG[7][5]==" ":
          n86["text"]=a
def n87():
     if tG[7][6]==" ":
          n87["text"]=a
def n88():
     if tG[7][7]==" ":
          n88["text"]=a
def n89():
     if tG[7][8]==" ":
          n89["text"]=a


def n91():
     if tG[8][0]==" ":
          n91["text"]=a
def n92():
     if tG[8][1]==" ":
          n92["text"]=a
def n93():
     if tG[8][2]==" ":
          n93["text"]=a
def n94():
     if tG[8][3]==" ":
          n94["text"]=a
def n95():
     if tG[8][4]==" ":
          n95["text"]=a
def n96():
     if tG[8][5]==" ":
          n96["text"]=a
def n97():
     if tG[8][6]==" ":
          n97["text"]=a
def n98():
     if tG[8][7]==" ":
          n98["text"]=a
def n99():
     if tG[8][8]==" ":
          n99["text"]=a

#Chnages Answer based on situation

ans=Label(text=" ",font=("Courier", 19))

def Correct():
     
     ans["text"]="Congratulations, you got it right!"
     ans.pack()
     
def Wrong():
     
     ans["text"]="Aww you got it wrong, Try again!"
     ans.pack()
     
fg=[]     
def submit():     
     global fg
     fg.append([n11["text"],n12["text"],n13["text"],n14["text"],n15["text"],n16["text"],n17["text"],n18["text"],n19["text"]])
     fg.append([n21["text"],n22["text"],n23["text"],n24["text"],n25["text"],n26["text"],n27["text"],n28["text"],n29["text"]])
     fg.append([n31["text"],n32["text"],n33["text"],n34["text"],n35["text"],n36["text"],n37["text"],n38["text"],n39["text"]])
     fg.append([n41["text"],n42["text"],n43["text"],n44["text"],n45["text"],n46["text"],n47["text"],n48["text"],n49["text"]])
     fg.append([n51["text"],n52["text"],n53["text"],n54["text"],n55["text"],n56["text"],n57["text"],n58["text"],n59["text"]])
     fg.append([n61["text"],n62["text"],n63["text"],n64["text"],n65["text"],n66["text"],n67["text"],n68["text"],n69["text"]])
     fg.append([n71["text"],n72["text"],n73["text"],n74["text"],n75["text"],n76["text"],n77["text"],n78["text"],n79["text"]])
     fg.append([n81["text"],n82["text"],n83["text"],n84["text"],n85["text"],n86["text"],n87["text"],n88["text"],n89["text"]])
     fg.append([n91["text"],n92["text"],n93["text"],n94["text"],n95["text"],n96["text"],n97["text"],n98["text"],n99["text"]])


     
     fG=[]
     for r in range(0,9):
          fG.append([])
          for c in range(0,9):
               if fg[r][c]==" ":
                    fG[r].append(0)
               else:
                    fG[r].append(fg[r][c])
     retry=0
     
     #Checks if answer is valid
     
     for i in range(0,81):
          row=i//9
          col=i%9
          if fG[row][col]==0:
            for value in range (1,10):
                 
        #Check that this value has not already be used on this row
                 
              if not(value in fG[row]):
                   
          #Check that this value has not already be used on this column
                   
                   if not value in (fG[0][col],fG[1][col],fG[2][col],fG[3][col],fG[4][col],fG[5][col],fG[6][col],fG[7][col],fG[8][col]):

            #Identify which of the 9 squares we are working on
                        square=[]
                        if row<3:
                          if col<3:
                            square=[fG[i][0:3] for i in range(0,3)]
                          elif col<6:
                            square=[fG[i][3:6] for i in range(0,3)]
                          else:  
                            square=[fG[i][6:9] for i in range(0,3)]
                        elif row<6:
                          if col<3:
                            square=[fG[i][0:3] for i in range(3,6)]
                          elif col<6:
                            square=[fG[i][3:6] for i in range(3,6)]
                          else:  
                            square=[fG[i][6:9] for i in range(3,6)]
                        else:
                          if col<3:
                            square=[fG[i][0:3] for i in range(6,9)]
                          elif col<6:
                            square=[fG[i][3:6] for i in range(6,9)]
                          else:  
                            square=[fG[i][6:9] for i in range(6,9)]
                            
                      #Check if the value has already been used in this 3x3 square
                            
                        if not value in (square[0] + square[1] + square[2]):
                            G[row][col]=value
                        else:
                             retry+=1
                   else:
                        retry+=1
              else:
                   retry+=1
     if retry==0: #Did the code need to backtrack even once to fix the user inputted solution?
          Correct()
     else:
          Wrong()

#Defines the Text used

Title=Label(start,text="SUDOKU",font=("Courier", 35))
Title.grid(row=0,column=0)

Emp1=Label(start,text="  ")
Emp1.grid(row=1,column=0)

Emp2=Label(mid,text="  ")
Emp2.grid(row=0,column=0)

Emp3=Label(end,text="\t \t \t \t \t \t \t")
bn = Label(end, text=a,font=("Courier", 20))
Emp3.grid(row=0,column=0)
bn.grid(row=0,column=1)

#Defines the Sudoku grid and its numbers

n11 = Button(sudtf, text=tG[0][0], width=2, height=1, bg="grey", fg="white", command=n11 )
n12 = Button(sudtf, text=tG[0][1], width=2, height=1, bg="grey", fg="white", command=n12 )
n13 = Button(sudtf, text=tG[0][2], width=2, height=1, bg="grey", fg="white", command=n13 )
n14 = Button(sudtf, text=tG[0][3], width=2, height=1, bg="grey", fg="white", command=n14 )
n15 = Button(sudtf, text=tG[0][4], width=2, height=1, bg="grey", fg="white", command=n15 )
n16 = Button(sudtf, text=tG[0][5], width=2, height=1, bg="grey", fg="white", command=n16 )
n17 = Button(sudtf, text=tG[0][6], width=2, height=1, bg="grey", fg="white", command=n17 )
n18 = Button(sudtf, text=tG[0][7], width=2, height=1, bg="grey", fg="white", command=n18 )
n19 = Button(sudtf, text=tG[0][8], width=2, height=1, bg="grey", fg="white", command=n19 )

n21 = Button(sudtf, text=tG[1][0], width=2, height=1, bg="grey", fg="white", command=n21 )
n22 = Button(sudtf, text=tG[1][1], width=2, height=1, bg="grey", fg="white", command=n22 )
n23 = Button(sudtf, text=tG[1][2], width=2, height=1, bg="grey", fg="white", command=n23 )
n24 = Button(sudtf, text=tG[1][3], width=2, height=1, bg="grey", fg="white", command=n24 )
n25 = Button(sudtf, text=tG[1][4], width=2, height=1, bg="grey", fg="white", command=n25 )
n26 = Button(sudtf, text=tG[1][5], width=2, height=1, bg="grey", fg="white", command=n26 )
n27 = Button(sudtf, text=tG[1][6], width=2, height=1, bg="grey", fg="white", command=n27 )
n28 = Button(sudtf, text=tG[1][7], width=2, height=1, bg="grey", fg="white", command=n28 )
n29 = Button(sudtf, text=tG[1][8], width=2, height=1, bg="grey", fg="white", command=n29 )

n31 = Button(sudtf, text=tG[2][0], width=2, height=1, bg="grey", fg="white", command=n31 )
n32 = Button(sudtf, text=tG[2][1], width=2, height=1, bg="grey", fg="white", command=n32 )
n33 = Button(sudtf, text=tG[2][2], width=2, height=1, bg="grey", fg="white", command=n33 )
n34 = Button(sudtf, text=tG[2][3], width=2, height=1, bg="grey", fg="white", command=n34 )
n35 = Button(sudtf, text=tG[2][4], width=2, height=1, bg="grey", fg="white", command=n35 )
n36 = Button(sudtf, text=tG[2][5], width=2, height=1, bg="grey", fg="white", command=n36 )
n37 = Button(sudtf, text=tG[2][6], width=2, height=1, bg="grey", fg="white", command=n37 )
n38 = Button(sudtf, text=tG[2][7], width=2, height=1, bg="grey", fg="white", command=n38 )
n39 = Button(sudtf, text=tG[2][8], width=2, height=1, bg="grey", fg="white", command=n39 )

n41 = Button(sudtf, text=tG[3][0], width=2, height=1, bg="grey", fg="white", command=n41 )
n42 = Button(sudtf, text=tG[3][1], width=2, height=1, bg="grey", fg="white", command=n42 )
n43 = Button(sudtf, text=tG[3][2], width=2, height=1, bg="grey", fg="white", command=n43 )
n44 = Button(sudtf, text=tG[3][3], width=2, height=1, bg="grey", fg="white", command=n44 )
n45 = Button(sudtf, text=tG[3][4], width=2, height=1, bg="grey", fg="white", command=n45 )
n46 = Button(sudtf, text=tG[3][5], width=2, height=1, bg="grey", fg="white", command=n46 )
n47 = Button(sudtf, text=tG[3][6], width=2, height=1, bg="grey", fg="white", command=n47 )
n48 = Button(sudtf, text=tG[3][7], width=2, height=1, bg="grey", fg="white", command=n48 )
n49 = Button(sudtf, text=tG[3][8], width=2, height=1, bg="grey", fg="white", command=n49 )

n51 = Button(sudtf, text=tG[4][0], width=2, height=1, bg="grey", fg="white", command=n51 )
n52 = Button(sudtf, text=tG[4][1], width=2, height=1, bg="grey", fg="white", command=n52 )
n53 = Button(sudtf, text=tG[4][2], width=2, height=1, bg="grey", fg="white", command=n53 )
n54 = Button(sudtf, text=tG[4][3], width=2, height=1, bg="grey", fg="white", command=n54 )
n55 = Button(sudtf, text=tG[4][4], width=2, height=1, bg="grey", fg="white", command=n55 )
n56 = Button(sudtf, text=tG[4][5], width=2, height=1, bg="grey", fg="white", command=n56 )
n57 = Button(sudtf, text=tG[4][6], width=2, height=1, bg="grey", fg="white", command=n57 )
n58 = Button(sudtf, text=tG[4][7], width=2, height=1, bg="grey", fg="white", command=n58 )
n59 = Button(sudtf, text=tG[4][8], width=2, height=1, bg="grey", fg="white", command=n59 )

n61 = Button(sudtf, text=tG[5][0], width=2, height=1, bg="grey", fg="white", command=n61 )
n62 = Button(sudtf, text=tG[5][1], width=2, height=1, bg="grey", fg="white", command=n62 )
n63 = Button(sudtf, text=tG[5][2], width=2, height=1, bg="grey", fg="white", command=n63 )
n64 = Button(sudtf, text=tG[5][3], width=2, height=1, bg="grey", fg="white", command=n64 )
n65 = Button(sudtf, text=tG[5][4], width=2, height=1, bg="grey", fg="white", command=n65 )
n66 = Button(sudtf, text=tG[5][5], width=2, height=1, bg="grey", fg="white", command=n66 )
n67 = Button(sudtf, text=tG[5][6], width=2, height=1, bg="grey", fg="white", command=n67 )
n68 = Button(sudtf, text=tG[5][7], width=2, height=1, bg="grey", fg="white", command=n68 )
n69 = Button(sudtf, text=tG[5][8], width=2, height=1, bg="grey", fg="white", command=n69 )

n71 = Button(sudtf, text=tG[6][0], width=2, height=1, bg="grey", fg="white", command=n71 )
n72 = Button(sudtf, text=tG[6][1], width=2, height=1, bg="grey", fg="white", command=n72 )
n73 = Button(sudtf, text=tG[6][2], width=2, height=1, bg="grey", fg="white", command=n73 )
n74 = Button(sudtf, text=tG[6][3], width=2, height=1, bg="grey", fg="white", command=n74 )
n75 = Button(sudtf, text=tG[6][4], width=2, height=1, bg="grey", fg="white", command=n75 )
n76 = Button(sudtf, text=tG[6][5], width=2, height=1, bg="grey", fg="white", command=n76 )
n77 = Button(sudtf, text=tG[6][6], width=2, height=1, bg="grey", fg="white", command=n77 )
n78 = Button(sudtf, text=tG[6][7], width=2, height=1, bg="grey", fg="white", command=n78 )
n79 = Button(sudtf, text=tG[6][8], width=2, height=1, bg="grey", fg="white", command=n79 )

n81 = Button(sudtf, text=tG[7][0], width=2, height=1, bg="grey", fg="white", command=n81 )
n82 = Button(sudtf, text=tG[7][1], width=2, height=1, bg="grey", fg="white", command=n82 )
n83 = Button(sudtf, text=tG[7][2], width=2, height=1, bg="grey", fg="white", command=n83 )
n84 = Button(sudtf, text=tG[7][3], width=2, height=1, bg="grey", fg="white", command=n84 )
n85 = Button(sudtf, text=tG[7][4], width=2, height=1, bg="grey", fg="white", command=n85 )
n86 = Button(sudtf, text=tG[7][5], width=2, height=1, bg="grey", fg="white", command=n86 )
n87 = Button(sudtf, text=tG[7][6], width=2, height=1, bg="grey", fg="white", command=n87 )
n88 = Button(sudtf, text=tG[7][7], width=2, height=1, bg="grey", fg="white", command=n88 )
n89 = Button(sudtf, text=tG[7][8], width=2, height=1, bg="grey", fg="white", command=n89 )

n91 = Button(sudtf, text=tG[8][0], width=2, height=1, bg="grey", fg="white", command=n91 )
n92 = Button(sudtf, text=tG[8][1], width=2, height=1, bg="grey", fg="white", command=n92 )
n93 = Button(sudtf, text=tG[8][2], width=2, height=1, bg="grey", fg="white", command=n93 )
n94 = Button(sudtf, text=tG[8][3], width=2, height=1, bg="grey", fg="white", command=n94 )
n95 = Button(sudtf, text=tG[8][4], width=2, height=1, bg="grey", fg="white", command=n95 )
n96 = Button(sudtf, text=tG[8][5], width=2, height=1, bg="grey", fg="white", command=n96 )
n97 = Button(sudtf, text=tG[8][6], width=2, height=1, bg="grey", fg="white", command=n97 )
n98 = Button(sudtf, text=tG[8][7], width=2, height=1, bg="grey", fg="white", command=n98 )
n99 = Button(sudtf, text=tG[8][8], width=2, height=1, bg="grey", fg="white", command=n99 )

#Creates the rows and columns for Sudoku

#Row 1
n11.grid(row=0,column=0)
n12.grid(row=0,column=1)
n13.grid(row=0,column=2)

v01.grid(row=0,column=3)

n14.grid(row=0,column=4)
n15.grid(row=0,column=5)
n16.grid(row=0,column=6)

v02.grid(row=0,column=7)

n17.grid(row=0,column=8)
n18.grid(row=0,column=9)
n19.grid(row=0,column=10)

#Row 2

n21.grid(row=1,column=0)
n22.grid(row=1,column=1)
n23.grid(row=1,column=2)

v03.grid(row=1,column=3)

n24.grid(row=1,column=4)
n25.grid(row=1,column=5)
n26.grid(row=1,column=6)

v04.grid(row=1,column=7)

n27.grid(row=1,column=8)
n28.grid(row=1,column=9)
n29.grid(row=1,column=10)

#Row 3

n31.grid(row=2,column=0)
n32.grid(row=2,column=1)
n33.grid(row=2,column=2)

v05.grid(row=2,column=3)

n34.grid(row=2,column=4)
n35.grid(row=2,column=5)
n36.grid(row=2,column=6)

v06.grid(row=2,column=7)

n37.grid(row=2,column=8)
n38.grid(row=2,column=9)
n39.grid(row=2,column=10)

#Row 4

h01.grid(row=3,column=0)
h02.grid(row=3,column=1)
h03.grid(row=3,column=2)

c01.grid(row=3,column=3)

h04.grid(row=3,column=4)
h05.grid(row=3,column=5)
h06.grid(row=3,column=6)

c02.grid(row=3,column=7)

h07.grid(row=3,column=8)
h08.grid(row=3,column=9)
h09.grid(row=3,column=10)

#Row 5

n41.grid(row=4,column=0)
n42.grid(row=4,column=1)
n43.grid(row=4,column=2)

v07.grid(row=4,column=3)

n44.grid(row=4,column=4)
n45.grid(row=4,column=5)
n46.grid(row=4,column=6)

v08.grid(row=4,column=7)

n47.grid(row=4,column=8)
n48.grid(row=4,column=9)
n49.grid(row=4,column=10)

#Row 6

n51.grid(row=5,column=0)
n52.grid(row=5,column=1)
n53.grid(row=5,column=2)

v09.grid(row=5,column=3)

n54.grid(row=5,column=4)
n55.grid(row=5,column=5)
n56.grid(row=5,column=6)

v10.grid(row=5,column=7)

n57.grid(row=5,column=8)
n58.grid(row=5,column=9)
n59.grid(row=5,column=10)

#Row 7

n61.grid(row=6,column=0)
n62.grid(row=6,column=1)
n63.grid(row=6,column=2)

v11.grid(row=6,column=3)

n64.grid(row=6,column=4)
n65.grid(row=6,column=5)
n66.grid(row=6,column=6)

v12.grid(row=6,column=7)

n67.grid(row=6,column=8)
n68.grid(row=6,column=9)
n69.grid(row=6,column=10)

#Row 8

h10.grid(row=7,column=0)
h11.grid(row=7,column=1)
h12.grid(row=7,column=2)

c03.grid(row=7,column=3)

h13.grid(row=7,column=4)
h14.grid(row=7,column=5)
h15.grid(row=7,column=6)

c04.grid(row=7,column=7)

h16.grid(row=7,column=8)
h17.grid(row=7,column=9)
h18.grid(row=7,column=10)

#Row 9

n71.grid(row=8,column=0)
n72.grid(row=8,column=1)
n73.grid(row=8,column=2)

v13.grid(row=8,column=3)

n74.grid(row=8,column=4)
n75.grid(row=8,column=5)
n76.grid(row=8,column=6)

v14.grid(row=8,column=7)

n77.grid(row=8,column=8)
n78.grid(row=8,column=9)
n79.grid(row=8,column=10)

n81.grid(row=9,column=0)
n82.grid(row=9,column=1)
n83.grid(row=9,column=2)

v15.grid(row=9,column=3)

n84.grid(row=9,column=4)
n85.grid(row=9,column=5)
n86.grid(row=9,column=6)

v16.grid(row=9,column=7)

n87.grid(row=9,column=8)
n88.grid(row=9,column=9)
n89.grid(row=9,column=10)

n91.grid(row=10,column=0)
n92.grid(row=10,column=1)
n93.grid(row=10,column=2)

v17.grid(row=10,column=3)

n94.grid(row=10,column=4)
n95.grid(row=10,column=5)
n96.grid(row=10,column=6)

v18.grid(row=10,column=7)

n97.grid(row=10,column=8)
n98.grid(row=10,column=9)
n99.grid(row=10,column=10)


#Defines the number Buttons and prints it in a grid    
               
b1 = Button(numf, text="1", width=3, height=2, bg="grey", fg="white", command=s1 )
b2 = Button(numf, text="2", width=3, height=2, bg="grey", fg="white", command=s2 )
b3 = Button(numf, text="3", width=3, height=2, bg="grey", fg="white", command=s3 )
b4 = Button(numf, text="4", width=3, height=2, bg="grey", fg="white", command=s4 )
b5 = Button(numf, text="5", width=3, height=2, bg="grey", fg="white", command=s5 )
b6 = Button(numf, text="6", width=3, height=2, bg="grey", fg="white", command=s6 )
b7 = Button(numf, text="7", width=3, height=2, bg="grey", fg="white", command=s7 )
b8 = Button(numf, text="8", width=3, height=2, bg="grey", fg="white", command=s8 )
b9 = Button(numf, text="9", width=3, height=2, bg="grey", fg="white", command=s9 )


b1.grid(row=0,column=0)
b2.grid(row=0,column=1)
b3.grid(row=0,column=2)
b4.grid(row=0,column=3)
b5.grid(row=0,column=4)
b6.grid(row=0,column=5)
b7.grid(row=0,column=6)
b8.grid(row=0,column=7)
b9.grid(row=0,column=8)

#Checks which buttons are predefined and need to be made white

if tG[0][0]!=" ":
     n11["bg"]="White"
     n11["fg"]="Black"
if tG[0][1]!=" ":
     n12["bg"]="White"
     n12["fg"]="Black"    
if tG[0][2]!=" ":
     n13["bg"]="White"
     n13["fg"]="Black"
if tG[0][3]!=" ":
     n14["bg"]="White"
     n14["fg"]="Black"
if tG[0][4]!=" ":
     n15["bg"]="White"
     n15["fg"]="Black"
if tG[0][5]!=" ":
     n16["bg"]="White"
     n16["fg"]="Black"
if tG[0][6]!=" ":
     n17["bg"]="White"
     n17["fg"]="Black"
if tG[0][7]!=" ":
     n18["bg"]="White"
     n18["fg"]="Black"
if tG[0][8]!=" ":
     n19["bg"]="White"
     n19["fg"]="Black"

if tG[1][0]!=" ":
     n21["bg"]="White"
     n21["fg"]="Black"
if tG[1][1]!=" ":
     n22["bg"]="White"
     n22["fg"]="Black"    
if tG[1][2]!=" ":
     n23["bg"]="White"
     n23["fg"]="Black"
if tG[1][3]!=" ":
     n24["bg"]="White"
     n24["fg"]="Black"
if tG[1][4]!=" ":
     n25["bg"]="White"
     n25["fg"]="Black"
if tG[1][5]!=" ":
     n26["bg"]="White"
     n26["fg"]="Black"
if tG[1][6]!=" ":
     n27["bg"]="White"
     n27["fg"]="Black"
if tG[1][7]!=" ":
     n28["bg"]="White"
     n28["fg"]="Black"
if tG[1][8]!=" ":
     n29["bg"]="White"
     n29["fg"]="Black"

if tG[2][0]!=" ":
     n31["bg"]="White"
     n31["fg"]="Black"
if tG[2][1]!=" ":
     n32["bg"]="White"
     n32["fg"]="Black"    
if tG[2][2]!=" ":
     n33["bg"]="White"
     n33["fg"]="Black"
if tG[2][3]!=" ":
     n34["bg"]="White"
     n34["fg"]="Black"
if tG[2][4]!=" ":
     n35["bg"]="White"
     n35["fg"]="Black"
if tG[2][5]!=" ":
     n36["bg"]="White"
     n36["fg"]="Black"
if tG[2][6]!=" ":
     n37["bg"]="White"
     n37["fg"]="Black"
if tG[2][7]!=" ":
     n38["bg"]="White"
     n38["fg"]="Black"
if tG[2][8]!=" ":
     n39["bg"]="White"
     n39["fg"]="Black"

if tG[3][0]!=" ":
     n41["bg"]="White"
     n41["fg"]="Black"
if tG[3][1]!=" ":
     n42["bg"]="White"
     n42["fg"]="Black"    
if tG[3][2]!=" ":
     n43["bg"]="White"
     n43["fg"]="Black"
if tG[3][3]!=" ":
     n44["bg"]="White"
     n44["fg"]="Black"
if tG[3][4]!=" ":
     n45["bg"]="White"
     n45["fg"]="Black"
if tG[3][5]!=" ":
     n46["bg"]="White"
     n46["fg"]="Black"
if tG[3][6]!=" ":
     n47["bg"]="White"
     n47["fg"]="Black"
if tG[3][7]!=" ":
     n48["bg"]="White"
     n48["fg"]="Black"
if tG[3][8]!=" ":
     n49["bg"]="White"
     n49["fg"]="Black"

if tG[4][0]!=" ":
     n51["bg"]="White"
     n51["fg"]="Black"
if tG[4][1]!=" ":
     n52["bg"]="White"
     n52["fg"]="Black"    
if tG[4][2]!=" ":
     n53["bg"]="White"
     n53["fg"]="Black"
if tG[4][3]!=" ":
     n54["bg"]="White"
     n54["fg"]="Black"
if tG[4][4]!=" ":
     n55["bg"]="White"
     n55["fg"]="Black"
if tG[4][5]!=" ":
     n56["bg"]="White"
     n56["fg"]="Black"
if tG[4][6]!=" ":
     n57["bg"]="White"
     n57["fg"]="Black"
if tG[4][7]!=" ":
     n58["bg"]="White"
     n58["fg"]="Black"
if tG[4][8]!=" ":
     n59["bg"]="White"
     n59["fg"]="Black"

if tG[5][0]!=" ":
     n61["bg"]="White"
     n61["fg"]="Black"
if tG[5][1]!=" ":
     n62["bg"]="White"
     n62["fg"]="Black"    
if tG[5][2]!=" ":
     n63["bg"]="White"
     n63["fg"]="Black"
if tG[5][3]!=" ":
     n64["bg"]="White"
     n64["fg"]="Black"
if tG[5][4]!=" ":
     n65["bg"]="White"
     n65["fg"]="Black"
if tG[5][5]!=" ":
     n66["bg"]="White"
     n66["fg"]="Black"
if tG[5][6]!=" ":
     n67["bg"]="White"
     n67["fg"]="Black"
if tG[5][7]!=" ":
     n68["bg"]="White"
     n68["fg"]="Black"
if tG[5][8]!=" ":
     n69["bg"]="White"
     n69["fg"]="Black"

if tG[6][0]!=" ":
     n71["bg"]="White"
     n71["fg"]="Black"
if tG[6][1]!=" ":
     n72["bg"]="White"
     n72["fg"]="Black"    
if tG[6][2]!=" ":
     n73["bg"]="White"
     n73["fg"]="Black"
if tG[6][3]!=" ":
     n74["bg"]="White"
     n74["fg"]="Black"
if tG[6][4]!=" ":
     n75["bg"]="White"
     n75["fg"]="Black"
if tG[6][5]!=" ":
     n76["bg"]="White"
     n76["fg"]="Black"
if tG[6][6]!=" ":
     n77["bg"]="White"
     n77["fg"]="Black"
if tG[6][7]!=" ":
     n78["bg"]="White"
     n78["fg"]="Black"
if tG[6][8]!=" ":
     n79["bg"]="White"
     n79["fg"]="Black"

if tG[7][0]!=" ":
     n81["bg"]="White"
     n81["fg"]="Black"
if tG[7][1]!=" ":
     n82["bg"]="White"
     n82["fg"]="Black"    
if tG[7][2]!=" ":
     n83["bg"]="White"
     n83["fg"]="Black"
if tG[7][3]!=" ":
     n84["bg"]="White"
     n84["fg"]="Black"
if tG[7][4]!=" ":
     n85["bg"]="White"
     n85["fg"]="Black"
if tG[7][5]!=" ":
     n86["bg"]="White"
     n86["fg"]="Black"
if tG[7][6]!=" ":
     n87["bg"]="White"
     n87["fg"]="Black"
if tG[7][7]!=" ":
     n88["bg"]="White"
     n88["fg"]="Black"
if tG[7][8]!=" ":
     n89["bg"]="White"
     n89["fg"]="Black"

if tG[8][0]!=" ":
     n91["bg"]="White"
     n91["fg"]="Black"
if tG[8][1]!=" ":
     n92["bg"]="White"
     n92["fg"]="Black"    
if tG[8][2]!=" ":
     n93["bg"]="White"
     n93["fg"]="Black"
if tG[8][3]!=" ":
     n94["bg"]="White"
     n94["fg"]="Black"
if tG[8][4]!=" ":
     n95["bg"]="White"
     n95["fg"]="Black"
if tG[8][5]!=" ":
     n96["bg"]="White"
     n96["fg"]="Black"
if tG[8][6]!=" ":
     n97["bg"]="White"
     n97["fg"]="Black"
if tG[8][7]!=" ":
     n98["bg"]="White"
     n98["fg"]="Black"
if tG[8][8]!=" ":
     n99["bg"]="White"
     n99["fg"]="Black"


#Creates the Submit and New button for Sudoku

sub = Button(last, text="Submit", width=10, height=2, bg="grey", fg="white", command=submit )

emp = Label(last,text="\t")

new = Button(last, text="New", width=10, height=2, bg="grey", fg="white", command=new )

sub.grid(row=0,column=0)
emp.grid(row=0,column=1)
new.grid(row=0,column=2)


wid.mainloop()
