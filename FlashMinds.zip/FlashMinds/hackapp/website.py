from flask import Flask, redirect, url_for, render_template, request#importing flask and other important modules
app = Flask(__name__)#app defined


            

            
@app.route("/")#Defining app route to access this page using this decorater
def home(): #defining home page
    return render_template("index.html")

'''@app.route("/login", methods=["POST","GET"])
def login():
    if request.method == "POST":
        user = request.form["nm"]
        return redirect(url_for("user", usr=user))
    else:    
        return render_template("login.html")

@app.route("/<usr>")
def user(usr):
    return f"<h1>{usr}</h1>"'''#we planned on adding a login signup page but we ran out of time though we will add it later versions

@app.route("/reactiontime")
def reactiontime():
        
    return render_template("reactiontime.html")#using render_template to render the templates in flask

@app.route("/hangman")#Defining the pages
def hangman():

    return render_template("hangman.html")

@app.route("/rockpaperscissor")
def rock_paper_scissor():
    return render_template("rock_paper_scissor.html")

@app.route("/tictactoe")
def tictactoe():
    return render_template("tictactoe.html")

@app.route("/verbalmemorytest")
def verbalmemorytest():
    return render_template("verbal memory test.html")

@app.route("/quadraticequation")
def quadraticequations():
    return render_template("quadraticequation.html")

@app.route("/randomopreator")
def randomoperator():
        
    return render_template("randomopreator.html")

@app.route("/aboutmath")
def aboutmath():
    return render_template("aboutmath.html")

@app.route("/aboutcognitive")    
def aboutcognitive():
    return render_template("aboutcognitive.html")

@app.route("/aboutfun")
def aboutfun():
    return render_template("aboutfun.html")

@app.route("/competitions")
def competitions():
    return render_template("competition.html")

@app.route("/aboutus")
def aboutus():
    return render_template("aboutus.html")



if __name__ == "__main__":   #Starting the app
    app.run(debug=True)  #Debug is true so then i dont have to keep on restarting my website instead i can just refresh and it will work
    

